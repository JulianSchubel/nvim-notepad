local Module = {
    window = nil,
    filepath = nil,
}

local function open_float(buf, opts)
    if Module.window and vim.api.nvim_win_is_valid(Module.window) then
        vim.api.nvim_set_current_win(Module.window)
        return
    end

    local width = math.floor(vim.o.columns * opts.width_ratio)
    local height = math.floor(vim.o.lines * opts.height_ratio)
    local row = math.floor((vim.o.lines - height) / 2)
    local col = math.floor((vim.o.columns - width) / 2)

    Module.window = vim.api.nvim_open_win(buf, true, {
        relative = "editor",
        row = row,
        col = col,
        width = width,
        height = height,
        style = "minimal",
        border = opts.border,
    })

    vim.bo[buf].filetype = "markdown"
    vim.bo[buf].bufhidden = "hide"
    vim.bo[buf].modifiable = true

    vim.wo[Module.window].wrap = true
    vim.wo[Module.window].linebreak = true

    vim.api.nvim_set_hl(0, "NormalFloat", { bg = "#1f2430" })
    vim.api.nvim_set_hl(0, "FloatBorder", { bg = "#1f2430", fg = "#6b7089" })
    vim.api.nvim_set_hl(0, "FloatTitle", { bg = "#1f2430", fg = "#6b7089" })

    -- Clear state if window is closed
    vim.api.nvim_create_autocmd("WinClosed", {
        once = true,
        callback = function()
            Module.window = nil
            Module.filepath = nil
        end
    })
end

local function open_right_split(buf, opts)
    vim.cmd("botright vsplit")
    vim.cmd("vertical resize " .. opts.split_width)

    Module.window = vim.api.nvim_get_current_win();
    vim.api.nvim_win_set_buf(Module.window, buf)

    vim.bo[buf].filetype = "markdown"
    vim.bo[buf].bufhidden = "hide"
    vim.bo[buf].modifiable = true

    vim.api.nvim_create_autocmd("WinClosed", {
        once = true,
        callback = function()
            Module.window = nil
            Module.filepath = nil
        end
    })
end

function Module.open(buf, path, opts)
    if Module.window and vim.api.nvim_win_is_valid(Module.window) then
        if Module.filepath == path then
            vim.api.nvim_set_current_win(Module.window)
            return
        end
        -- Update the referenced filepath
        Module.filepath = path
        return
    end

    -- No window currently exists
    Module.filepath = path

    -- Determine which window to use based on the configured layout
    if opts.layout == "right" then
        return open_right_split(buf, opts)
    else
        return open_float(buf, opts)
    end
end

function Module.close()
    --Only close a window if one is open and it is valid
    if Module.window and vim.api.nvim_win_is_valid(Module.window) then
        vim.api.nvim_win_close(Module.window, true)
    end
end

return Module
