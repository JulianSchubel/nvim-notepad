local M = {}

local config = require("notepad.config").opts

local frontmatter = require("notepad.features.flashcards.frontmatter")

-- Atomic write helper
local function atomic_write(path, lines)
    local tmp = path .. ".tmp"

    vim.fn.writefile(lines, tmp)

    -- fsync is implicit on rename in POSIX
    assert(vim.loop.fs_rename(tmp, path), "Atomic rename failed")
end

-- Write full card safely
function M.write_card(card)
    assert(card.path, "card.path missing")
    assert(card.metadata, "card.metadata missing")

    local lines = vim.fn.readfile(card.path)
    local fm, body = frontmatter.read(lines)

    -- idempotent update (see next section)
    fm.notepad = fm.notepad or {}
    fm.notepad.flashcard = fm.notepad.flashcard or {}
    fm.notepad.flashcard.fsrs = card.metadata.fsrs

    local new_lines = frontmatter.write(body, fm)

    atomic_write(card.path, new_lines)
end

-- Recursively scan a directory for markdown files
local function scan_dir(dir, results)
    results = results or {}

    local handle = vim.loop.fs_scandir(dir)
    if not handle then
        return results
    end

    while true do
        local name, type = vim.loop.fs_scandir_next(handle)
        if not name then break end

        local path = dir .. "/" .. name

        if type == "file" and name:sub(-3) == ".md" then
            table.insert(results, {
                path  = path,
                lines = vim.fn.readfile(path),
            })
        elseif type == "directory" then
            scan_dir(path, results)
        end
    end

    return results
end

-- Public API
function M.scan_markdown()
    local vault_path = config.flashcards.vault_path
    assert(type(vault_path) == "string", "vault_path must be a string")

    return scan_dir(vault_path, {})
end

return M
