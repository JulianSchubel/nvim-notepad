local parser  = require("notepad.features.flashcards.parser")
local storage = require("notepad.features.flashcards.storage")

local M = {}

function M.due_today()

    local now = os.time()
    local due_cards = {}

    for _, file in ipairs(storage.scan_markdown()) do
        -- file = { path, lines }
        local cards = parser.parse_file(
            file.lines,
            { path = file.path }
        )

        for _, card in ipairs(cards) do
            if card.fsrs and card.fsrs.due and card.fsrs.due <= now then
                table.insert(due_cards, card)
            end
        end
    end

    return due_cards
end

return M

