-- FSRS schema handling
local fsrs = require("notepad.features.flashcards.fsrs")

local M = {}

local DEFAULT_STATE = {
    stability      = 0.0,
    difficulty     = 5.0,
    elapsed_days   = 0,
    scheduled_days = 0,
    reps           = 0,
    lapses         = 0,
    last_review    = nil,
    due            = nil,
}

local SCHEMA_VERSION = 1

local function validate(state)
    assert(type(state) == "table", "FSRS state must be a table")
    assert(type(state.stability) == "number", "FSRS.stability must be number")
    assert(type(state.difficulty) == "number", "FSRS.difficulty must be number")
    assert(type(state.reps) == "number", "FSRS.reps must be number")
    assert(type(state.lapses) == "number", "FSRS.lapses must be number")
end

function M.default_fsrs_state(now)
  local fsrs = require("notepad.features.flashcards.fsrs")
  now = now or os.time()

  return {
    stability        = fsrs.init_stability(3),
    difficulty       = fsrs.init_difficulty(),
    elapsed_days     = 0,
    scheduled_days   = 0,
    reps             = 0,
    lapses           = 0,
    last_review      = now,
    due              = now,
    version          = SCHEMA_VERSION,
  }
end

function M.ensure(metadata)
    metadata = metadata or {}

    local src = type(metadata.fsrs) == "table" and metadata.fsrs or {}
    local fsrs_state = {}

    for k, v in pairs(DEFAULT_STATE) do
        fsrs_state[k] = src[k] ~= nil and src[k] or v
    end

    fsrs_state.version = src.version or SCHEMA_VERSION

    validate(fsrs_state)
    return fsrs_state
end

function M.encode_fsrs(card, fsrs_state)
    validate(fsrs_state)

    card.metadata = card.metadata or {}
    card.metadata.fsrs = vim.tbl_extend("force", {}, fsrs_state)
    card.metadata.fsrs.version = SCHEMA_VERSION
end

return M
