-- Review state machine
-- review.lua decides what changes; storage.lua decides how it is written.
local fsrs    = require("notepad.features.flashcards.fsrs")
local schema  = require("notepad.features.flashcards.schema")
local storage = require("notepad.features.flashcards.storage")

local M       = {}

-- Start a review session
function M.start(card)
    return {
        card = card,
        state = schema.ensure(card.metadata),
        started_at = os.time(),
    }
end

-- Apply a rating and commit FSRS update
function M.apply_rating(session, rating)
    local now = os.time()

    -- 1. Run FSRS
    local next_state = fsrs.review(
        session.state,
        rating,
        now
    )

    -- 2. Encode FSRS back into card metadata
    schema.encode_fsrs(session.card, next_state)

    -- 3. Persist atomically
    storage.write_card(session.card)

    -- 4. Update session
    session.state = next_state

    return next_state
end

return M
