local M = {}

-- functions here
function M.init_stability(rating) ... end
function M.init_difficulty() ... end
function M.review(...) ... end

return M

