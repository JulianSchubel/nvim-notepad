-- Lua port of the official FSRS (Free Spaced Repitition Scheduler) algorithm
-- Pure FSRS scheduler
local M = {}

-- FSRS ratings (reference)
M.RATING = {
    AGAIN = 1,
    HARD  = 2,
    GOOD  = 3,
    EASY  = 4,
}

-- Official FSRS default weights (13)
M.DEFAULT_W = {
    0.4, 0.6, 2.4, 5.8, 4.93,
    0.94, 0.86, 0.01, 1.49,
    0.14, 0.94, 2.18, 0.05
}

-- Clamp helper
local function clamp(x, min, max)
    return math.max(min, math.min(max, x))
end

-- Forgetting curve: r = e^(-t / s)
local function forgetting_curve(elapsed_days, stability)
    return math.exp(-elapsed_days / stability)
end

-- Initial stability based on first rating
function M.init_stability(rating)
    if rating == 1 then return 0.1 end
    if rating == 2 then return 1.0 end
    if rating == 3 then return 3.0 end
    return 5.0
end

-- Initial difficulty (reference default)
function M.init_difficulty()
    return 5.0
end

-- Core FSRS transition
function M.next_state(state, rating, elapsed_days, w)
    w = w or M.DEFAULT_W

    local s = state.stability
    local d = state.difficulty

    local r = forgetting_curve(elapsed_days, s)

    -- Difficulty update
    d = clamp(
        d + w[6] * (rating - 3),
        1, 10
    )

    -- Stability update
    if rating < 3 then
        -- Failed recall
        s = w[1] * math.pow(s, w[2])
    else
        -- Successful recall
        s = s * (
            1
            + math.exp(w[3])
            * (11 - d)
            * math.pow(s, -w[4])
            * (math.exp((1 - r) * w[5]) - 1)
        )
    end

    return {
        stability = s,
        difficulty = d,
    }
end

-- Interval is floor(stability) days
function M.next_interval_days(stability)
    return math.max(1, math.floor(stability))
end

return M
