describe("due_today query", function()
  local query = require("notepad.features.flashcards.query")

  it("returns overdue cards", function()
    local cards = query.due_today("/tmp/vault")
    assert.is_table(cards)
  end)
end)

