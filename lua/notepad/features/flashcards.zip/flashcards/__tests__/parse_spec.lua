local parser = require("notepad.features.flashcards.parser")

describe("Markdown flashcard parser", function()
    it("parses inline cards", function()
        local cards = parser.parse([[
What is 2+2? :: 4
]])
        assert.equals(1, #cards)
        assert.equals("What is 2+2?", cards[1].front)
        assert.equals("4", cards[1].back)
    end)

    it("parses callout flashcards", function()
        local cards = parser.parse([[
> [!flashcard]
> What is TCP?
> Transmission Control Protocol
]])
        assert.equals(1, #cards)
        assert.equals("What is TCP?", cards[1].front)
        assert.equals("Transmission Control Protocol", cards[1].back)
    end)

    it("ignores non-flashcard callouts", function()
        local cards = parser.parse([[
> [!note]
> Just a note
]])
        assert.equals(0, #cards)
    end)
end)
