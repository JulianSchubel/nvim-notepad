-- Parse markdown into flashcards
--[[ Supported patterns 



]]

local M = {}

-- Utility: strip leading "> " safely
local function strip_quote(line)
    return line:gsub("^>%s?", "")
end

--[[ Parse Obsidian flashcard callouts
    Supported pattern:
        ∙ A line with > [!flashcard])
        ∙ First paragraph -> question
        ∙ Remaining content -> answer
]]
local function parse_callouts(lines, source)
    local flashcards = {}
    local i = 1

    while i <= #lines do
        if lines[i]:match("^>%s*%[!flashcard%]") then
            i = i + 1

            local question_lines = {}
            local answer_lines = {}
            local current = question_lines

            while i <= #lines and lines[i]:match("^>") do
                local content = strip_quote(lines[i])

                if content == "" and current == question_lines then
                    current = answer_lines
                else
                    table.insert(current, content)
                end

                i = i + 1
            end

            table.insert(flashcards, {
                question = table.concat(question_lines, "\n"),
                answer   = table.concat(answer_lines, "\n"),
                source   = {
                    path = source.path,
                    line = source.line,
                    type = "callout",
                },
            })
        else
            i = i + 1
        end
    end

    return flashcards
end


--[[ Question and Answer Pairs
    Supported Pattern
        ∙ Question line -> Q:: What is Lua?
        ∙ Answer line A:: A lightweight embeddable scripting language.
        ∙ Where a flashcard tag (#flashcard) is indicated
        ∙ Example: 
            Q:: What is FSRS? 
            A:: FSRS is a modern spaced repetition algorithm
                designed to optimize long-term memory.
--]]
local function parse_qna_pairs(lines, source)
    local flashcards = {}

    assert(type(lines) == "table", "parse_qna_pairs expects lines[]")

    for _, line in ipairs(lines) do
        local question = nil;
        local answer = nil;
        if line:match("^Q::") then
            question = line:gsub("^Q::%s*", "");
        elseif line:match("^A::") and question then
            answer = line:gsub("^A::%s*", "")
            table.insert(flashcards, {
                question = question,
                answer   = answer,
                source   = {
                    path = source.path,
                    line = source.line,
                    type = "qna",
                },
            })
        end
    end

    return flashcards
end


local function trim(s)
  return s:match("^%s*(.-)%s*$")
end

--[[ 
    Supported Pattern
        ∙ Single line
        ∙ First `::` splits question / answer
        ∙ Example: What is the capital of France? :: Paris
]]
local function parse_inline(lines, source)
    local flashcards = {}
    for _, line in ipairs(lines) do
        if line:find("::") then
            local front, back = line:match("^(.-)::(.-)$")
            if front and back then
                table.insert(flashcards, {
                    question = trim(front),
                    answer   = trim(back),
                    source   = {
                        path = source.path,
                        line = source.line,
                        type = "inline",
                    },
                })
            end
        end
    end

    return flashcards
end

local frontmatter = require("notepad.features.flashcards.frontmatter")
local schema = require("notepad.features.flashcards.schema")

--[[
Extracts flashcards using the configured supported patterns
]]
function M.parse_file(lines, source)
    local meta = frontmatter.read(lines)
    meta.notepad = meta.notepad or {}
    meta.notepad.flashcard = meta.notepad.flashcard or {}

    meta.notepad.flashcard.fsrs =
        meta.notepad.flashcard.fsrs
        or schema.default_fsrs_state()

    local flashcards = {}
    vim.list_extend(flashcards, parse_qna_pairs(lines, source))
    vim.list_extend(flashcards, parse_callouts(lines, source))
    vim.list_extend(flashcards, parse_inline(lines, source))

    return {
        cards = flashcards,
        metadata = meta.notepad.flashcard,
        raw = lines,
        path = source.path,
    }
end

return M;
