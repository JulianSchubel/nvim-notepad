local M = {}

-- Neovim 0.10+ provides toml encode/decode
local toml = vim.fn

-- Read TOML frontmatter
function M.read(lines)
    if lines[1] ~= "+++" then
        return {}, lines
    end

    local fm_lines = {}
    local body_start = nil

    for i = 2, #lines do
        if lines[i] == "+++" then
            body_start = i + 1
            break
        end
        table.insert(fm_lines, lines[i])
    end

    local fm_text = table.concat(fm_lines, "\n")
    local fm = {}

    if fm_text ~= "" then
        fm = toml.toml_decode(fm_text)
    end

    local body = vim.list_slice(lines, body_start)
    return fm or {}, body
end

-- Write TOML frontmatter (idempotent)
function M.write(body, fm)
    local encoded = toml.toml_encode(fm)

    local result = {
        "+++",
    }

    for line in encoded:gmatch("[^\n]+") do
        table.insert(result, line)
    end

    table.insert(result, "+++")
    vim.list_extend(result, body)

    return result
end

return M
